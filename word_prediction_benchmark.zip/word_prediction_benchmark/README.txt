Images are reference by the flickr-id (abbreviated as fid).

ids_to_nouns.pik - [ (fid, [noun1, noun2 ...]) , ... ] the list of nouns associated with each image in the dataset.

train_ids.pik - [fid1, fid2, fid3 ....] list of flickr-ids used for training the detectors

train_calibrate_ids.pik - [fid1, fid2, fid3 ...] list of flickr-ids used for calibrating the detectors against each other

train_ids_order.pik - [fid1, fid2, fid3 ...] list of flickr-ids used for training the RankSVM noun ordering approach

test_ids.pik - [fid1, fid2, fid3 ...] list of flickr-ids used for testing. This corresponds to the SBU-148K dataset.

